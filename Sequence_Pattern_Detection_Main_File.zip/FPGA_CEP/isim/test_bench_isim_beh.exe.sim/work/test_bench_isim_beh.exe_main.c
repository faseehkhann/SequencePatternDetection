/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    xilinxcorelib_ver_m_00000000001358910285_1469759452_init();
    xilinxcorelib_ver_m_00000000001687936702_1033733843_init();
    xilinxcorelib_ver_m_00000000000277421008_4166113091_init();
    xilinxcorelib_ver_m_00000000001485706734_1561961145_init();
    work_m_00000000000403262735_2679401303_init();
    xilinxcorelib_ver_m_00000000000277421008_2646264339_init();
    xilinxcorelib_ver_m_00000000001485706734_0920823149_init();
    work_m_00000000000403262735_4079712463_init();
    xilinxcorelib_ver_m_00000000000277421008_2145148724_init();
    xilinxcorelib_ver_m_00000000001485706734_4118601674_init();
    work_m_00000000000403262735_2797533781_init();
    work_m_00000000003531883828_0005776894_init();
    work_m_00000000000924415066_3708592143_init();
    work_m_00000000002656218173_2578365841_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000002656218173_2578365841");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
